import json, copy
p='/mnt/data/cm_work/data.json'
D=json.load(open(p))
lab_templates={
'IE1':('Electrical Lab','Electrical engineering laboratory for electrical circuits, measurements, wiring, electrical machines and basic power-system experiments.',30,[
('Digital Multimeter','📟',12,'Electrical measurement instrument used to measure voltage, current, resistance and continuity.'),('AC/DC Ammeter','⚡',8,'Measures current in AC and DC electrical circuits.'),('Voltmeter','🔌',8,'Measures potential difference across electrical components and circuits.'),('Rheostat','🎚️',10,'Variable resistor used to control current during electrical experiments.'),('Transformer Trainer','🔋',4,'Used to study transformer operation, voltage transformation and efficiency.'),('Resistor Kit','🧰',20,'Contains resistors of different values for circuit-building and measurement experiments.'),('Capacitor Kit','🔋',20,'Provides capacitors of different values for charging, discharging and circuit experiments.'),('Electrical Wires & Leads','🔗',40,'Used to make safe electrical connections between components and instruments.'),('Single-Phase Motor Trainer','⚙️',3,'Used to study the construction, operation and characteristics of electrical motors.')]),
'IE2':('Electronics Lab','Electronics laboratory for analog and digital electronics, semiconductor devices, waveform analysis and circuit design.',30,[
('Digital Multimeter','📟',12,'Measures voltage, current, resistance, continuity and diode parameters in electronic circuits.'),('Oscilloscope','〰️',6,'Displays electrical waveforms and measures amplitude, frequency, time period and phase.'),('Function Generator','〰️',6,'Generates sine, square and other test waveforms for electronic circuit experiments.'),('DC Regulated Power Supply','🔌',10,'Provides controlled DC voltage and current to electronic circuits.'),('Breadboard','🧩',20,'Allows electronic circuits to be assembled and tested without soldering.'),('Resistor Kit','🧰',30,'Provides resistor values for analog and digital circuit experiments.'),('Capacitor Kit','🔋',25,'Provides capacitors for filtering, timing, coupling and other electronics experiments.'),('Diode Kit','💡',20,'Contains diodes for rectifier, clipping, clamping and switching experiments.'),('Transistor Kit','🔧',20,'Contains BJT and transistor devices for amplification and switching experiments.'),('IC / Digital Logic Kit','🧠',15,'Contains common logic ICs for digital electronics and Boolean-logic experiments.')]),
'DE1':('Microcontrollers and Microprocessor Lab','Practical laboratory for microcontrollers, microprocessors, embedded programming, interfacing, sensors and trainer-kit experiments.',30,[
('Desktop Computer','💻',30,'Used for writing, compiling, debugging and simulating embedded-system programs.'),('8051 Microcontroller Kit','🧠',15,'Trainer board for programming the 8051 family and learning ports, timers, interrupts and interfacing.'),('8086 Microprocessor Trainer','🖥️',10,'Trainer kit for learning 8086 architecture, assembly programming and hardware interfacing.'),('Arduino Development Kit','🔌',15,'Microcontroller development platform for embedded programming and sensor/actuator experiments.'),('Embedded Sensor Kit','📡',12,'Contains sensors used for temperature, light, distance and other embedded-system measurements.'),('Programmer / Debugger','🛠️',10,'Used to upload firmware and debug supported microcontroller development boards.'),('Digital Multimeter','📟',6,'Used to verify supply voltage, continuity and electrical connections in embedded circuits.'),('Jumper Wire Kit','🔗',30,'Provides jumper wires for connecting trainer boards, sensors and microcontroller modules.')]),
'DE2':('Computer Lab','Computer laboratory containing desktop systems for programming, software development, simulations, networking, documentation and practical sessions.',40,[
('Desktop Computer','💻',40,'Used for programming, software development, simulations, documentation and practical classes.'),('Keyboard & Mouse Set','⌨️',40,'Standard input devices used with each desktop workstation.'),('UPS Unit','🔋',20,'Provides short-term backup power and protects computer systems from power interruptions.'),('Network Switch','🌐',4,'Connects multiple computers to the local laboratory network.'),('LAN Cable Set','🔗',50,'Used to connect computers and network devices for networking practicals.'),('Headset','🎧',20,'Used for audio-based programming, language, multimedia or online practical sessions.'),('Webcam','📷',10,'Used for video communication, online classes and multimedia practical work.'),('Projector','📽️',2,'Displays instructor demonstrations, presentations and software walkthroughs to the class.')])
}
# normalize all 5 floors
for fi,f in enumerate(D['floors'],1):
    # remove any old labs and rebuild exact four labs
    classes=[r for r in f['rooms'] if r['type']=='classroom']
    labs=[]
    for code in ['IE1','IE2','DE1','DE2']:
        name,desc,cap,items=lab_templates[code]
        equip=[]
        for idx,(ename,icon,qty,use) in enumerate(items,1):
            eid=f"f{fi}-{code.lower()}-{idx}"
            equip.append({'id':eid,'name':ename,'icon':icon,'category':code,'location':f'{code} Equipment Area {chr(64+((idx-1)%4)+1)}-{((idx-1)//4)+1:02d}','quantity':qty,'use':use,'tutorial':['Check the equipment before use.','Connect or configure it according to the lab procedure.','Record readings and return the equipment safely after the experiment.'],'problems':['Incorrect connection or setup','Equipment does not power on','Ask the lab assistant if the issue continues']})
        labs.append({'id':f'f{fi}-{code.lower()}','number':code,'type':'laboratory','name':name,'capacity':cap,'description':desc,'equipment':equip})
    # exact class numbers and preserve existing schedules
    classes=[]
    for n in range(1,7):
        num=f'{fi}{n:02d}'
        cid=f'class-{num}'
        old=next((r for r in f['rooms'] if r['id']==cid),None)
        classes.append({'id':cid,'number':num,'type':'classroom','name':f'Classroom {num}','capacity':60,'description':f'Classroom {num} for lectures, tutorials, seminars and academic sessions on the {f["name"]}.','equipment':[]})
        if cid not in D['classSchedules']:
            D['classSchedules'][cid]=[]
    f['rooms']=labs+classes
    f['name']=f'{fi}st Floor' if fi==1 else f'{fi}nd Floor' if fi==2 else f'{fi}rd Floor' if fi==3 else f'{fi}th Floor'
D['campus']['tagline']='One smart interface for 5 floors, laboratories, classrooms & equipment'
open(p,'w').write(json.dumps(D,indent=2))
