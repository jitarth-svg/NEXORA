# Campus Memory — Redesigned (Glass + Skeuomorphic UI)

## What changed
- **Visual system**: hybrid glassmorphism + skeuomorphism. Frosted, blurred glass
  panels sit inside a dark "device bezel" chrome (hero cards, equipment panel,
  footer), with neumorphic dual-shadow buttons/cards and glowing LED-style status
  indicators (teal = available, amber = occupied, indigo = lab).
- **Typography**: Space Grotesk for headings/numerics (technical, panel-like),
  Inter for body text — both modern and professional, not childish.
- **Interactivity**: Existing ripple/toast/keyboard-shortcut behavior preserved. Cursor-following background and reactive sheen effects have been removed.
- **Bugs found & fixed during QA**:
  - Login screen no longer bleeds through behind the home page
  - Favorite-star buttons now align to the top-right correctly
  - Admin equipment rows and favorite cards no longer run title/subtitle
    text together on one line
- Light and dark mode are both fully re-themed via CSS variables (the
  existing toggle button still works — ☼ / ☾).

## Running it
Open `index.html` through a local server — the app `fetch()`s `data.json`,
which needs http(s), not `file://`. Easiest options:
- VS Code "Live Server" extension, or
- `python3 -m http.server` from this folder, then visit `http://localhost:8000`

## Files
- `index.html` — markup (added font links, background/cursor-glow layers)
- `style.css` — full visual redesign (rewritten from scratch)
- `script.js` — original app logic, unchanged, plus an additive interactivity layer
- `data.json`, `update.py` — unchanged from the original project


## AI Advisor update
- Removed the cursor-following background glow and cursor-reactive 3D card effect.
- Added **AI Advisor** entry points throughout the app: header, home, floor/room pages, room details, equipment details, favorites and admin.
- Added a context-aware AI modal with campus-data-aware prompts.
- Added `server.js` as a local backend proxy so the AI credential is not sent to browser JavaScript.
- Added `.env` with the supplied Gemini credential and Gemini `generateContent` configuration.
- Added `.env.example` and `.gitignore`.

### Run with AI
1. Install Node.js 18+.
2. From this folder run `node server.js`.
3. Open `http://localhost:8000`.
4. Do not deploy `.env` publicly. If the supplied key has been shared elsewhere, revoke/rotate it in the provider console.
