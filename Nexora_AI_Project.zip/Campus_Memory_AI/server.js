
const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

function loadEnv() {
  const file = path.join(__dirname, ".env");
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let value = m[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1,-1);
    if (!process.env[m[1]]) process.env[m[1]] = value;
  }
}
loadEnv();

const PORT = Number(process.env.PORT || 8000);
const API_KEY = process.env.AI_ADVISOR_API_KEY || process.env.GEMINI_API_KEY;
const MODEL = process.env.AI_ADVISOR_MODEL || "gemini-3.6-flash";
const API_URL = process.env.AI_ADVISOR_API_URL || "https://generativelanguage.googleapis.com/v1beta/interactions";

if (!API_KEY) console.warn("AI_ADVISOR_API_KEY is not configured.");

function send(res, status, body, contentType="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type": contentType, "Cache-Control":"no-store"});
  res.end(Buffer.isBuffer(body) || body instanceof Uint8Array ? body : (typeof body === "string" ? body : JSON.stringify(body)));
}
function safeFilePath(urlPath) {
  const clean = decodeURIComponent(urlPath.split("?")[0]);
  const requested = clean === "/" ? "/index.html" : clean;
  const full = path.normalize(path.join(__dirname, requested));
  if (!full.startsWith(path.normalize(__dirname + path.sep))) return null;
  return full;
}
async function aiAdvisor(req,res) {
  if (!API_KEY) return send(res,500,{error:"AI_ADVISOR_API_KEY is missing in .env"});
  let raw="";
  req.on("data", chunk => { raw += chunk; if (raw.length > 350000) req.destroy(); });
  req.on("end", async () => {
    try {
      const body = JSON.parse(raw || "{}");
      const prompt = String(body.prompt || "").trim();
      if (!prompt) return send(res,400,{error:"Prompt is required"});
      const input = buildAIInput(prompt, body);
      const geminiBody = {
        model: MODEL,
        input,
        stream: true,
        generation_config: {
          thinking_level: "minimal",
          max_output_tokens: 500,
          thinking_summaries: "none"
        },
        store: false
      };
      const api = API_URL;
      let upstream;
      try {
        upstream = await fetch(api, {
          method:"POST",
          headers:{"Content-Type":"application/json","x-goog-api-key":API_KEY,"Accept":"text/event-stream"},
          body:JSON.stringify(geminiBody)
        });
      } catch (networkError) {
        return send(res,502,{error:`Could not reach Gemini: ${networkError.message || networkError}`});
      }
      if (!upstream.ok) {
        const text = await upstream.text().catch(()=>"");
        let parsed={}; try{parsed=JSON.parse(text)}catch{}
        const providerMessage = parsed?.error?.message || text || `AI provider returned HTTP ${upstream.status}`;
        return send(res,502,{error:providerMessage, providerStatus:upstream.status, provider:parsed?.error?.status || null});
      }
      res.writeHead(200,{"Content-Type":"text/event-stream; charset=utf-8","Cache-Control":"no-cache, no-store","Connection":"keep-alive","X-Accel-Buffering":"no"});
      if (!upstream.body) return res.end();
      const reader=upstream.body.getReader();
      const decoder=new TextDecoder();
      try{
        while(true){
          const {done,value}=await reader.read();
          if(done) break;
          res.write(decoder.decode(value,{stream:true}));
        }
      } finally { res.end(); }
    } catch (e) {
      if (!res.headersSent) return send(res,500,{error:e.message || "AI request failed"});
      res.end();
    }
  });
}

function buildAIInput(prompt, body){
  const campus=body?.campus||{};
  const context=String(body?.context||"");
  const rooms=Array.isArray(campus.rooms)?campus.rooms:[];
  const timetable=rooms.filter(r=>r.type==="classroom").map(r=>({
    id:r.id, number:r.number, name:r.name, floor:r.floor, capacity:r.capacity,
    schedule:Array.isArray(r.schedule)?r.schedule:[]
  }));
  const roomIndex=rooms.map(r=>({id:r.id,number:r.number,name:r.name,type:r.type,floor:r.floor,capacity:r.capacity,description:r.description,equipment:(r.equipment||[]).map(e=>({name:e.name,quantity:e.quantity,location:e.location,use:e.use}))}));
  return `You are Nexora AI Advisor, a fast practical assistant for a college campus information system.
Generate a fresh independent answer for every request. Answer campus-specific questions ONLY from the supplied campus data. Never invent room availability, timetable slots, equipment or locations.
For empty-classroom questions, use the TIMETABLE DATA below as the source of truth. A slot with status "Empty" is available; "Occupied" is not. If the user gives a time, match that exact time. If no time is given, list the useful empty slots and rooms. Mention the room number, floor and capacity when useful.
Keep answers concise and actionable. For lab equipment, include safe-use guidance and advise following campus lab rules/supervisor instructions.
Current page context: ${context || "General campus"}
TIMETABLE DATA:
${JSON.stringify(timetable)}
ROOM/EQUIPMENT DATA:
${JSON.stringify(roomIndex)}
USER REQUEST:
${prompt}`;
}

function offlineAdvisor(prompt, body){
  const p=prompt.toLowerCase();
  const campus=body?.campus||{};
  const rooms=Array.isArray(campus.rooms)?campus.rooms:[];
  if(/empty|available|free|vacant/.test(p)){
    const available=rooms.filter(r=>r.type==="classroom").map(r=>r.number||r.name).slice(0,8);
    return available.length ? `I can help you find available classrooms. The campus data currently includes these classroom locations: ${available.join(", ")}. Check the timetable for the exact empty slot before heading there.` : "I could not find classroom availability in the current campus data.";
  }
  if(/equipment|multimeter|oscilloscope|component|instrument/.test(p)){
    const items=rooms.flatMap(r=>(r.equipment||[]).map(e=>`${e.name} (${r.name})`)).slice(0,10);
    return items.length ? `Campus equipment I can see includes: ${items.join(", ")}. Open an equipment item for its stored location and usage information.` : "I could not find equipment information in the current campus data.";
  }
  if(/lab|laboratory|practical/.test(p)){
    const labs=rooms.filter(r=>r.type==="laboratory").map(r=>`${r.name} (${r.number})`).slice(0,8);
    return labs.length ? `The campus data lists these laboratories: ${labs.join(", ")}. Choose based on the equipment and practical requirements shown in each lab.` : "I could not find laboratory information in the current campus data.";
  }
  if(/direction|where|locat|find/.test(p)){
    return "I can help with campus navigation. Select a room or equipment item first so I can use its stored campus context and give more specific guidance.";
  }
  return `Nexora AI Advisor is connected to the campus data. I can help with rooms, classroom availability, laboratories, equipment, favorites and navigation. Your question was: “${prompt}”. Ask me about a specific room, lab, equipment item or available classroom.`;
}

const server=http.createServer((req,res)=>{
  const u=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  if(req.method==="POST" && u.pathname==="/api/ai-advisor") return aiAdvisor(req,res);
  if(req.method!=="GET") return send(res,405,{error:"Method not allowed"});
  const file=safeFilePath(u.pathname);
  if(!file) return send(res,403,{error:"Forbidden"});
  fs.readFile(file,(err,data)=>{
    if(err) return send(res,404,{error:"Not found"});
    const ext=path.extname(file).toLowerCase();
    const types={".html":"text/html; charset=utf-8",".js":"application/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json; charset=utf-8",".md":"text/plain; charset=utf-8"};
    send(res,200,data,types[ext]||"application/octet-stream");
  });
});
server.listen(PORT,()=>console.log(`Nexora running at http://localhost:${PORT}`));
