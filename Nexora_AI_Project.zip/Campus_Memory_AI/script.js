let data, role=localStorage.getItem("nx_role")||null, currentFloor=null, currentRoom=null, currentEquipment=null, currentFilter="all";
async function init(){
  try{
    const response=await fetch("data.json");
    if(!response.ok) throw new Error("Could not load data.json");
    data=await response.json();
    if(role){showPage("home");updateRoleUI();renderFloors();updateHomeWidgets()}else{showPage("login")};
  }catch(error){
    console.error(error);
    updateRoleUI();
    toast("Please run this project with VS Code Live Server");
  }
}
init();
let favorites = JSON.parse(localStorage.getItem("cm_favorites") || "[]");
let recentItems = JSON.parse(localStorage.getItem("cm_recent") || "[]");

function saveFavorites(){localStorage.setItem("cm_favorites",JSON.stringify(favorites));updateHomeWidgets()}
function saveRecent(){localStorage.setItem("cm_recent",JSON.stringify(recentItems.slice(0,6)));updateHomeWidgets()}
function favoriteKey(type,id){return type+":"+id}
function isFavorite(type,id){return favorites.includes(favoriteKey(type,id))}
function toggleFavorite(type,id){
  const key=favoriteKey(type,id);
  if(favorites.includes(key)){favorites=favorites.filter(x=>x!==key);toast("Removed from favorites")}
  else{favorites.unshift(key);toast("Added to favorites ⭐")}
  saveFavorites(); updateFavoriteButtons();
}
function toggleCurrentFavorite(){
  if(currentEquipment) toggleFavorite("equipment",currentEquipment.id);
  else if(currentRoom) toggleFavorite("room",currentRoom.id);
}
function addRecent(type,id,title,sub){
  recentItems=[{type,id,title,sub},...recentItems.filter(x=>!(x.type===type&&x.id===id))].slice(0,6);
  saveRecent();
}
function updateFavoriteButtons(){
  const roomBtn=document.getElementById("roomFavoriteBtn"), equipBtn=document.getElementById("equipFavoriteBtn");
  if(roomBtn&&currentRoom){roomBtn.textContent=isFavorite("room",currentRoom.id)?"★":"☆";roomBtn.classList.toggle("is-favorite",isFavorite("room",currentRoom.id))}
  if(equipBtn&&currentEquipment){equipBtn.textContent=isFavorite("equipment",currentEquipment.id)?"★":"☆";equipBtn.classList.toggle("is-favorite",isFavorite("equipment",currentEquipment.id))}
}
function updateHomeWidgets(){
  const rooms=data?.floors.flatMap(f=>f.rooms)||[];
  const labs=rooms.filter(r=>r.type==="laboratory").length, classes=rooms.filter(r=>r.type==="classroom").length;
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v};
  set("statRooms",rooms.length);set("statLabs",labs);set("statClasses",classes);set("statFavorites",favorites.length);
  const favBox=document.getElementById("favoritePreview"), recentBox=document.getElementById("recentPreview");
  if(!favBox||!recentBox)return;
  const favData=favorites.slice(0,4).map(key=>{
    const [type,id]=key.split(":");
    if(type==="room"){const f=data.floors.find(f=>f.rooms.some(r=>r.id===id)),r=f?.rooms.find(r=>r.id===id);return r?{type,id,title:r.name,sub:`${r.number} • ${f.name}`}:null}
    const found=getAllEquipment().find(x=>x.e.id===id);return found?{type,id,title:found.e.name,sub:`${found.r.name} • ${found.f.name}`}:null;
  }).filter(Boolean);
  favBox.innerHTML=favData.length?favData.map(x=>`<div class="mini-item" onclick="openSaved('${x.type}','${x.id}')"><div><b>${x.title}</b><small>${x.sub}</small></div><span>★</span></div>`).join(""):'<p class="muted">Save rooms or equipment with the ☆ button.</p>';
  recentBox.innerHTML=recentItems.length?recentItems.slice(0,4).map(x=>`<div class="mini-item" onclick="openSaved('${x.type}','${x.id}')"><div><b>${x.title}</b><small>${x.sub}</small></div><span>›</span></div>`).join(""):'<p class="muted">Your recent rooms and equipment will appear here.</p>';
}
function openSaved(type,id){
  if(type==="room"){const f=data.floors.find(f=>f.rooms.some(r=>r.id===id));if(f){openFloor(f.id);setTimeout(()=>openRoom(id),50)}}
  else {const found=getAllEquipment().find(x=>x.e.id===id);if(found){openEquipment(id)}}
}
function showFavorites(){
  showPage("favorites");const box=document.getElementById("favoritesGrid");
  const items=favorites.map(key=>{const [type,id]=key.split(":");if(type==="room"){const f=data.floors.find(f=>f.rooms.some(r=>r.id===id)),r=f?.rooms.find(r=>r.id===id);return r?{type,id,title:r.name,number:r.number,sub:`${f.name} • ${r.type==="laboratory"?"Laboratory":"Classroom"}`}:null}const x=getAllEquipment().find(x=>x.e.id===id);return x?{type,id,title:x.e.name,number:x.e.icon,sub:`${x.r.name} • ${x.f.name}`}:null}).filter(Boolean);
  box.innerHTML=items.length?items.map(x=>`<div class="favorite-card" onclick="openSaved('${x.type}','${x.id}')"><div><b>${x.number} ${x.title}</b><small>${x.sub}</small></div><button class="favorite-btn is-favorite" onclick="event.stopPropagation();toggleFavorite('${x.type}','${x.id}');showFavorites()">★</button></div>`).join(""):'<div class="panel"><h3>No favorites yet</h3><p class="muted">Open a room or equipment item and tap ☆ to save it here.</p></div>';
}
function toggleTheme(){
  document.body.classList.toggle("dark");
  const dark=document.body.classList.contains("dark");
  localStorage.setItem("cm_theme",dark?"dark":"light");
  const b=document.getElementById("themeToggle");if(b)b.textContent=dark?"☾":"☼";
  toast(dark?"Dark mode enabled":"Light mode enabled");
}
function restoreTheme(){
  if(localStorage.getItem("cm_theme")==="dark"){document.body.classList.add("dark");const b=document.getElementById("themeToggle");if(b)b.textContent="☾"}
}
restoreTheme();


function showPage(id){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById(id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"})}
function goHome(){if(!role){showPage("login");return}showPage("home")}
function startExplore(type){showPage("explore");if(type)sessionStorage.setItem("roomType",type);else sessionStorage.removeItem("roomType")}
function updateRoleUI(){document.getElementById("roleBadge").textContent=role==="admin"?"Admin":"Student";document.getElementById("adminQuick").style.display=role==="admin"?"block":"none";document.getElementById("loggedInAs").textContent=role==="admin"?"🛠 Logged in as Admin":"🎓 Logged in as Student";document.getElementById("siteHeader").style.display=role?"flex":"none";document.getElementById("siteFooter").style.display=role?"flex":"none"}
function toggleRoleMenu(){document.getElementById("roleMenu").classList.toggle("hidden")}
function showLoginForm(which){const student=which==="student";document.getElementById("studentLoginForm").classList.toggle("hidden",!student);document.getElementById("adminLoginForm").classList.toggle("hidden",student);document.getElementById("studentLoginTab").classList.toggle("active",student);document.getElementById("adminLoginTab").classList.toggle("active",!student)}
function studentLogin(event){event.preventDefault();const id=document.getElementById("studentId").value.trim();if(!id)return;role="student";localStorage.setItem("nx_role","student");localStorage.setItem("cm_student_id",id);updateRoleUI();showPage("home");toast("Student login successful")}
function adminLogin(event){event.preventDefault();const email=document.getElementById("adminEmail").value.trim().toLowerCase(),password=document.getElementById("adminPassword").value;if(email==="admin@nexora.com"&&password==="admin123"){role="admin";localStorage.setItem("nx_role","admin");localStorage.setItem("nx_admin_email",email);updateRoleUI();showPage("home");toast("Admin login successful")}else toast("Invalid admin email or password")}
function logout(){role=null;localStorage.removeItem("nx_role");localStorage.removeItem("cm_student_id");localStorage.removeItem("nx_admin_email");document.getElementById("roleMenu").classList.add("hidden");showLoginForm("student");showPage("login");toast("Logged out")}

function renderFloors(){
 const grid=document.getElementById("floorGrid");
 grid.innerHTML=data.floors.map(f=>`<button class="floor-card" onclick="openFloor('${f.id}')"><span class="eyebrow">FLOOR</span><div class="floor-no">${f.name.replace(" Floor","")}</div><b>${f.name}</b><small>${f.rooms.length} rooms • ${f.rooms.filter(r=>r.type==="laboratory").length} labs • ${f.rooms.filter(r=>r.type==="classroom").length} classrooms</small></button>`).join("");
}
function openFloor(id){currentFloor=data.floors.find(f=>f.id===id);const preferred=sessionStorage.getItem("roomType");document.getElementById("roomsEyebrow").textContent=currentFloor.name.toUpperCase();document.getElementById("roomsTitle").textContent=preferred==="laboratory"?"Choose a laboratory":preferred==="classroom"?"Choose a classroom":"Choose a room";showPage("rooms");currentFilter=preferred||"all";renderRoomFilters();renderRooms()}
function renderRoomFilters(){const preferred=sessionStorage.getItem("roomType"),box=document.getElementById("roomFilters");if(preferred){box.innerHTML=`<span class="filter active">${preferred==="laboratory"?"🔬 Laboratories":"🏫 Classrooms"}</span>`}else{box.innerHTML=`<button class="filter active" onclick="filterRooms('all',this)">All</button><button class="filter" onclick="filterRooms('laboratory',this)">🔬 Laboratories</button><button class="filter" onclick="filterRooms('classroom',this)">🏫 Classrooms</button>`}}
function filterRooms(type,btn){currentFilter=type;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderRooms()}
function renderRooms(){
 let rooms=currentFloor.rooms.filter(r=>currentFilter==="all"||r.type===currentFilter);
 document.getElementById("roomGrid").innerHTML=rooms.map(r=>{
   const availability=r.type==="classroom"?getClassAvailability(r):null;
   const availabilityBadge=r.type==="classroom"?`<span class="availability ${availability.emptyCount>0?"available":"full"}">${availability.emptyCount>0?"🟢 Available":"🔴 Fully occupied"}</span>`:`<span class="availability lab">🔬 Lab</span>`;
   const availabilityText=r.type==="classroom"?(availability.emptyCount>0?`<b>${availability.emptyCount}</b> empty slot${availability.emptyCount===1?"":"s"} today`:`No empty slots in today's timetable`):`${r.equipment.length} equipment/component types • ${r.capacity} seats`;
   return `<div class="room-card" onclick="openRoom('${r.id}')"><div class="room-top"><span class="type-pill">${r.type==="laboratory"?"🔬 LABORATORY":"🏫 CLASSROOM"}</span><span class="room-number">${r.number}</span></div><div class="room-status-row">${availabilityBadge}</div><h3>${r.name}</h3><p>${r.description}</p><div class="room-meta"><span>👥 ${r.capacity}</span><span>📍 ${currentFloor.name}</span></div><div class="availability-note">${availabilityText}</div></div>`;
 }).join("")||"<p>No rooms found.</p>";
}
function getClassAvailability(room){
 const schedule=data.classSchedules[room.id]||[];
 const empty=schedule.filter(s=>s.status==="Empty");
 return {schedule,emptySlots:empty,emptyCount:empty.length};
}
function findRoom(id){for(const f of data.floors){const r=f.rooms.find(x=>x.id===id);if(r)return r}return null}
function openRoom(id){currentRoom=findRoom(id);currentEquipment=null;document.getElementById("detailEyebrow").textContent=(currentRoom.type==="laboratory"?"LABORATORY ":"CLASSROOM ")+currentRoom.number;document.getElementById("detailTitle").textContent=currentRoom.name;document.getElementById("detailDesc").textContent=currentRoom.description;addRecent("room",currentRoom.id,currentRoom.name,`${currentRoom.number} • ${currentFloor.name}`);showPage("roomDetail");updateFavoriteButtons();currentRoom.type==="laboratory"?renderLab():renderClass()}
function renderLab(){
 const labEquipment=getAllEquipment().filter(x=>x.r.id===currentRoom.id).map(x=>x.e);
 const totalQty=labEquipment.reduce((sum,e)=>sum+Number(getQty(e)||0),0);
 document.getElementById("classDetail").classList.add("hidden");const box=document.getElementById("labDetail");box.classList.remove("hidden");
 box.innerHTML=`<div class="detail-grid"><div class="panel"><span class="eyebrow">LAB INFORMATION</span><h2>Lab ${currentRoom.number}</h2><div class="lab-purpose"><b>${currentRoom.name}</b><span>Purpose-built laboratory</span></div><p><b>Purpose:</b> ${currentRoom.description}</p><p><b>Capacity:</b> ${currentRoom.capacity} students</p><p><b>Floor:</b> ${currentFloor.name}</p><p><b>Inventory:</b> ${labEquipment.length} equipment/component types • ${totalQty} total units</p><div class="map-box"><div><b>📍 Lab ${currentRoom.number}</b><br><small>Floor ${currentFloor.name.split(" ")[0]} • Direction map</small><br><button class="secondary" style="margin-top:14px" onclick="showDirection()">Get directions</button></div></div></div>
 <div class="panel"><span class="eyebrow">EQUIPMENT & COMPONENTS</span><h2>What's inside this lab?</h2><div class="equipment-list">${labEquipment.map(e=>`<div class="equipment-card" onclick="openEquipment('${e.id}')"><div class="icon">${e.icon}</div><b>${e.name}</b><span class="component-tag">${e.category||"LAB COMPONENT"}</span><small>Qty ${getQty(e)} • ${getLoc(e)}</small></div>`).join("")}</div></div></div>`;
}
function renderClass(){
 document.getElementById("labDetail").classList.add("hidden");const box=document.getElementById("classDetail");box.classList.remove("hidden");const schedule=data.classSchedules[currentRoom.id]||[];
 const availability=getClassAvailability(currentRoom),empty=availability.emptyCount;
 box.innerHTML=`<div class="class-summary"><div class="stat"><span class="eyebrow">CAPACITY</span><b>${currentRoom.capacity}</b><small>students</small></div><div class="stat"><span class="eyebrow">EMPTY SLOTS</span><b>${empty}</b><small>available today</small></div><div class="stat"><span class="eyebrow">ROOM</span><b>${currentRoom.number}</b><small>${currentFloor.name}</small></div></div>
 <div class="panel"><span class="eyebrow">TODAY'S TIMETABLE</span><h2>Classroom availability</h2><div class="availability-banner ${empty>0?"available":"full"}"><b>${empty>0?"🟢 Classroom has empty slots":"🔴 No empty slots"}</b><span>${empty} empty slot${empty===1?"":"s"} today</span></div><table class="schedule">${schedule.map(s=>`<tr><td>${s.time}</td><td>${s.subject}</td><td class="${s.status==="Empty"?"empty":"occupied"}">${s.status}</td></tr>`).join("")}</table><div class="map-box"><div><b>🧭 Find Classroom ${currentRoom.number}</b><br><small>Use the campus direction map to reach this room.</small><br><button class="secondary" style="margin-top:14px" onclick="showDirection()">Get directions</button></div></div></div>`;
}
function getStored(){try{return JSON.parse(localStorage.getItem("cm_equipment")||"{}")}catch{return{}}}
function getAdded(){try{return JSON.parse(localStorage.getItem("cm_added_equipment")||"[]")}catch{return[]}}
function getQty(e){return getStored()[e.id]?.quantity??e.quantity}
function getLoc(e){return getStored()[e.id]?.location??e.location}
function getAllEquipment(){const all=[];data.floors.forEach(f=>f.rooms.filter(r=>r.type==="laboratory").forEach(r=>r.equipment.forEach(e=>all.push({f,r,e}))));getAdded().forEach(e=>{const f=data.floors.find(x=>x.id===e.floorId),r=f?.rooms.find(x=>x.id===e.roomId);if(f&&r)all.push({f,r,e})});return all}
function openEquipment(id){const found=getAllEquipment().find(x=>x.e.id===id);if(!found)return;currentRoom=found.r;currentFloor=found.f;currentEquipment=found.e;document.getElementById("equipTitle").textContent=currentEquipment.name;document.getElementById("equipName").textContent=currentEquipment.name;document.getElementById("equipIcon").textContent=currentEquipment.icon;document.getElementById("equipLocation").textContent="📍 "+getLoc(currentEquipment)+" • Quantity: "+getQty(currentEquipment)+(currentEquipment.category?" • "+currentEquipment.category:"");addRecent("equipment",currentEquipment.id,currentEquipment.name,`${currentRoom.name} • ${currentFloor.name}`);showPage("equipmentDetail");updateFavoriteButtons();equipTab("overview",document.querySelector(".tab"))}
function equipTab(which,btn){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");const c=document.getElementById("equipContent");if(which==="overview")c.innerHTML=`<h3>What is it used for?</h3><p>${currentEquipment.use||"General laboratory equipment used for practical work."}</p><h3>Location & quantity</h3><p>📍 ${getLoc(currentEquipment)}<br>📦 ${getQty(currentEquipment)} available</p>`;if(which==="tutorial")c.innerHTML=`<h3>Quick tutorial</h3><ol>${(currentEquipment.tutorial||["Check the equipment before use.","Connect or configure it as required.","Use it according to the laboratory procedure."]).map(x=>`<li>${x}</li>`).join("")}</ol>`;if(which==="problems")c.innerHTML=`<h3>Common problems students face</h3><ul>${(currentEquipment.problems||["Equipment does not turn on","Incorrect connection","Check the user manual or ask the lab assistant"]).map(x=>`<li>${x}</li>`).join("")}</ul>`}
function showDirection(){if(!currentRoom)return;document.getElementById("routeDestination").textContent=(currentRoom.type==="laboratory"?"Lab ":"Room ")+currentRoom.number;document.getElementById("routeFloor").textContent=currentFloor.name;document.getElementById("routeRoom").textContent=currentRoom.name+" ("+currentRoom.number+")";document.getElementById("directionModal").classList.remove("hidden")}
function closeDirection(){document.getElementById("directionModal").classList.add("hidden")}
function findEmptyClassrooms(){const rooms=[];data.floors.forEach(f=>f.rooms.filter(r=>r.type==="classroom").forEach(r=>{const schedule=data.classSchedules[r.id]||[],empty=schedule.filter(s=>s.status==="Empty");rooms.push({f,r,empty})}));showPage("rooms");currentFloor=data.floors[0];document.getElementById("roomsEyebrow").textContent="CAMPUS";document.getElementById("roomsTitle").textContent="Classrooms & Empty Slots";document.getElementById("roomFilters").innerHTML=`<span class="filter active">🟢 Empty Classrooms</span>`;document.getElementById("roomGrid").innerHTML=rooms.map(({f,r,empty})=>`<div class="room-card" onclick="openFloor('${f.id}');setTimeout(()=>openRoom('${r.id}'),50)"><div class="room-top"><span class="type-pill">🏫 CLASSROOM</span><span class="room-number">${r.number}</span></div><div class="room-status-row"><span class="availability ${empty.length?"available":"full"}">${empty.length?"🟢 Empty slots available":"🔴 Fully occupied"}</span></div><h3>${r.name}</h3><p><b>${empty.length}</b> empty timetable slot${empty.length===1?"":"s"} available today.</p><div class="empty-slot-list">${empty.length?empty.map(s=>`<span>${s.time}</span>`).join(""):"<span class=\"occupied-chip\">No empty slots</span>"}</div><div class="room-meta"><span>👥 ${r.capacity}</span><span>📍 ${f.name}</span></div></div>`).join("");toast("Showing classroom availability")}
function showAdmin(){if(role!=="admin"){toast("Switch to Admin mode first");return}renderAdmin();showPage("admin")}
function renderAdmin(){const labs=[];data.floors.forEach(f=>f.rooms.filter(r=>r.type==="laboratory").forEach(r=>labs.push({f,r})));const labOptions=labs.map(({f,r})=>`<option value="${f.id}|${r.id}">${f.name} — ${r.number} (${r.name})</option>`).join("");const list=getAllEquipment();document.getElementById("adminList").innerHTML=`<div class="admin-tabs"><button class="admin-tab active" onclick="adminTab('equipment',this)">📦 Equipment</button><button class="admin-tab" onclick="adminTab('empty',this)">🟢 Empty Classrooms</button></div><div id="adminEquipmentTab"><div class="admin-add panel"><span class="eyebrow">ADD EQUIPMENT</span><h2>Add equipment to a laboratory</h2><p>Create a new equipment/component entry. It will appear in that lab immediately.</p><div class="add-grid"><input id="newEquipName" placeholder="Equipment name"><input id="newEquipIcon" placeholder="Icon / emoji" value="🔧"><select id="newEquipLab">${labOptions}</select><input id="newEquipQty" type="number" min="0" value="1" placeholder="Quantity"><input id="newEquipLoc" placeholder="Location"><input id="newEquipUse" placeholder="What is it used for?"><input id="newEquipTutorial" placeholder="Tutorial steps separated by |"><input id="newEquipProblems" placeholder="Common problems separated by |"></div><button class="primary" onclick="addEquipment()">＋ Add Equipment</button></div><div class="admin-section-head"><div><span class="eyebrow">MANAGE EQUIPMENT</span><h2>Quantity & location</h2></div><span class="admin-count">${list.length} equipment entries</span></div>${list.map(({f,r,e})=>`<div class="admin-item"><div><b>${e.icon||"🔧"} ${e.name}</b><small>${r.name} • ${r.number} • ${f.name}</small></div><div><label>Quantity</label><input id="q-${e.id}" type="number" min="0" value="${getQty(e)}"></div><div><label>Location</label><input id="l-${e.id}" value="${getLoc(e)}"></div><button class="save" onclick="saveEquip('${e.id}')">Save</button></div>`).join("")}</div><div id="adminEmptyTab" class="hidden"></div>`}
function adminTab(which,btn){document.querySelectorAll(".admin-tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");document.getElementById("adminEquipmentTab").classList.toggle("hidden",which!=="equipment");document.getElementById("adminEmptyTab").classList.toggle("hidden",which!=="empty");if(which==="empty")renderAdminEmpty()}
function renderAdminEmpty(){
 const out=[];data.floors.forEach(f=>f.rooms.filter(r=>r.type==="classroom").forEach(r=>{const schedule=data.classSchedules[r.id]||[],empty=schedule.filter(s=>s.status==="Empty");out.push({f,r,empty})}));
 const total=out.reduce((n,x)=>n+x.empty.length,0);
 const cards=out.map(x=>{const slots=x.empty.length?x.empty.map(s=>`<span>${s.time}</span>`).join(""):"<span class=\"occupied-chip\">Fully occupied</span>";return `<div class="empty-admin-card"><div class="room-top"><span class="type-pill">🏫 CLASSROOM</span><span class="room-number">${x.r.number}</span></div><h3>${x.r.name}</h3><p>${x.empty.length} empty slot${x.empty.length===1?"":"s"}</p><div class="empty-slot-list">${slots}</div><button class="secondary" onclick="openFloor('${x.f.id}');setTimeout(()=>openRoom('${x.r.id}'),50)">View Classroom</button></div>`}).join("");
 document.getElementById("adminEmptyTab").innerHTML=`<div class="admin-section-head"><div><span class="eyebrow">CLASSROOM AVAILABILITY</span><h2>Empty classrooms</h2><p>View every classroom and its currently empty timetable slots.</p></div><span class="admin-count">${total} empty slots</span></div><div class="empty-admin-grid">${cards}</div>`;
}
function saveEquip(id){const old=getStored();old[id]={quantity:Math.max(0,Number(document.getElementById("q-"+id).value)||0),location:document.getElementById("l-"+id).value.trim()||"Location not specified"};localStorage.setItem("cm_equipment",JSON.stringify(old));toast("Equipment details updated");renderAdmin();if(currentRoom&&currentRoom.type==="laboratory")renderLab()}
function addEquipment(){const name=document.getElementById("newEquipName").value.trim(),selected=document.getElementById("newEquipLab").value.split("|");if(!name){toast("Enter an equipment name");return}const item={id:"added-"+Date.now(),name,icon:document.getElementById("newEquipIcon").value.trim()||"🔧",quantity:Math.max(0,Number(document.getElementById("newEquipQty").value)||0),location:document.getElementById("newEquipLoc").value.trim()||"Location not specified",use:document.getElementById("newEquipUse").value.trim()||"Laboratory equipment used for practical work.",tutorial:document.getElementById("newEquipTutorial").value.split("|").map(x=>x.trim()).filter(Boolean),problems:document.getElementById("newEquipProblems").value.split("|").map(x=>x.trim()).filter(Boolean),floorId:selected[0],roomId:selected[1]};const added=getAdded();added.push(item);localStorage.setItem("cm_added_equipment",JSON.stringify(added));toast(name+" added successfully");renderAdmin()}
function openSearch(){document.getElementById("searchModal").classList.remove("hidden");document.getElementById("searchInput").focus();doSearch()}
function closeSearch(){document.getElementById("searchModal").classList.add("hidden")}
function doSearch(){
  if(!data){
    document.getElementById("searchResults").innerHTML="<p>Campus data is still loading. If this stays here, run the folder with Live Server.</p>";
    return;
  }
  const q=document.getElementById("searchInput").value.toLowerCase().trim();
  const results=[];
  data.floors.forEach(f=>{
    f.rooms.forEach(r=>{
      if(!q||r.name.toLowerCase().includes(q)||r.number.includes(q)){
        results.push({
          title:r.name+" • "+r.number,
          sub:f.name+" • "+(r.type==="laboratory"?"Laboratory":"Classroom"),
          action:()=>{closeSearch();openFloor(f.id);setTimeout(()=>openRoom(r.id),50)}
        });
      }
      getAllEquipment().filter(x=>x.r.id===r.id).forEach(({e})=>{
        if(!q||e.name.toLowerCase().includes(q)){
          results.push({title:e.name,sub:r.name+" • "+f.name,action:()=>{closeSearch();openFloor(f.id);setTimeout(()=>openRoom(r.id),50)}});
        }
      });
    });
  });
  document.getElementById("searchResults").innerHTML=
    results.slice(0,10).map((x,i)=>`<div class="result" onclick="searchActions[${i}]()"><b>${x.title}</b><small>${x.sub}</small></div>`).join("")
    ||"<p>No results found.</p>";
  window.searchActions=results.map(x=>x.action);
}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeSearch();closeDirection()}})

document.addEventListener("click",function(e){
  const btn=e.target.closest("button");
  if(!btn || btn.disabled) return;
  const rect=btn.getBoundingClientRect(), ripple=document.createElement("span");
  ripple.className="ripple";const size=Math.max(rect.width,rect.height);
  ripple.style.width=ripple.style.height=size+"px";
  ripple.style.left=(e.clientX-rect.left-size/2)+"px";ripple.style.top=(e.clientY-rect.top-size/2)+"px";
  btn.appendChild(ripple);setTimeout(()=>ripple.remove(),600);
});
document.addEventListener("keydown",e=>{
  if(e.key==="/" && document.activeElement.tagName!=="INPUT" && document.activeElement.tagName!=="TEXTAREA"){e.preventDefault();openSearch()}
  if(e.key==="f" && document.activeElement.tagName!=="INPUT" && document.activeElement.tagName!=="TEXTAREA" && currentRoom){toggleCurrentFavorite()}
});

/* ==========================================================================
   Interactive polish layer (visual only — does not touch app state/logic)
   ========================================================================== */

/* Keep the theme-toggle icon glyph in sync on load (visual nicety) */
document.addEventListener("DOMContentLoaded", function () {
  var dark = document.body.classList.contains("dark");
  var b = document.getElementById("themeToggle");
  if (b) b.textContent = dark ? "☾" : "☼";
});

/* ==========================================================================
   AI Campus Advisor
   The browser talks only to the local server. The Gemini credential stays
   server-side in .env instead of being exposed to page JavaScript.
   ========================================================================== */
let aiContextText="";
function campusSnapshot(){
  const rooms=data?.floors?.flatMap(f=>f.rooms.map(r=>({
    floor:f.name,id:r.id,number:r.number,name:r.name,type:r.type,capacity:r.capacity,
    description:r.description,
    equipment:(r.equipment||[]).map(e=>({id:e.id,name:e.name,quantity:e.quantity})),
    schedule:r.type==="classroom" ? (data?.classSchedules?.[r.id]||[]) : []
  })))||[];
  return {rooms, role:role||"guest", currentRoom:currentRoom?.id||null, currentEquipment:currentEquipment?.id||null};
}
function openAIAdvisor(context){
  const modal=document.getElementById("aiModal"); if(!modal)return;
  modal.classList.remove("hidden");
  const c=context || (currentEquipment ? `Equipment: ${currentEquipment.name}. Location: ${currentEquipment.location}. Use: ${currentEquipment.use}.`
    : currentRoom ? `Room: ${currentRoom.name} (${currentRoom.number}). ${currentRoom.description}`
    : "General Nexora help. The AI can also use classroom timetable data for availability questions.");
  aiContextText=c;
  document.getElementById("aiContext").textContent=c;
  const input=document.getElementById("aiPrompt");
  input.focus();
}
function closeAIAdvisor(){document.getElementById("aiModal")?.classList.add("hidden")}
function useAISuggestion(text){document.getElementById("aiPrompt").value=text;askAI()}
function askAIAboutCurrent(){
  if(currentEquipment){
    openAIAdvisor(`Equipment: ${currentEquipment.name}. Location: ${currentEquipment.location}. Quantity: ${getQty(currentEquipment)}. Purpose: ${currentEquipment.use}. Common problems: ${(currentEquipment.problems||[]).join("; ")}.`);
  }else if(currentRoom){
    const schedule=currentRoom.type==="classroom"?(data.classSchedules?.[currentRoom.id]||[]):[];
    openAIAdvisor(`Room: ${currentRoom.name} (${currentRoom.number}), ${currentRoom.type}. Capacity: ${currentRoom.capacity}. ${currentRoom.description}${schedule.length?` Timetable: ${schedule.map(s=>`${s.time}=${s.status}${s.subject&&s.subject!=="—"?` (${s.subject})`:""}`).join("; ")}`:""}`);
  }else openAIAdvisor();
}
function handleAIPromptKeydown(event){
  if(event.key==="Enter" && !event.shiftKey){event.preventDefault();if(!document.getElementById("aiAskBtn")?.disabled)askAI();}
}
async function askAI(){
  const prompt=document.getElementById("aiPrompt").value.trim();
  if(!prompt){toast("Ask the AI Advisor a question first");return}
  const btn=document.getElementById("aiAskBtn"), out=document.getElementById("aiResponse");
  btn.disabled=true; btn.textContent="Thinking…"; out.innerHTML='<div class="ai-loading">✦ AI Advisor is thinking…</div>';
  try{
    const response=await fetch("/api/ai-advisor",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({prompt,context:aiContextText,campus:campusSnapshot()})
    });
    if(!response.ok){const payload=await response.json().catch(()=>({}));throw new Error(payload.error||"AI service request failed")}
    if(!response.body)throw new Error("AI stream was not available");
    out.innerHTML='<div class="ai-answer"></div>';
    const answer=out.querySelector(".ai-answer");
    const reader=response.body.getReader(); const decoder=new TextDecoder(); let buffer=""; let fullText="";
    while(true){
      const {done,value}=await reader.read();
      if(done)break;
      buffer+=decoder.decode(value,{stream:true});
      const events=buffer.split(/\r?\n\r?\n/); buffer=events.pop()||"";
      for(const event of events){
        const lines=event.split(/\r?\n/); let eventData="";
        for(const line of lines){if(line.startsWith("data:"))eventData += line.slice(5).trim();}
        if(!eventData || eventData==="[DONE]")continue;
        let item;try{item=JSON.parse(eventData)}catch{continue}
        if(item.event_type==="error")throw new Error(item.error?.message||"Gemini streaming error");
        if(item.event_type==="step.delta" && item.delta?.type==="text"){
          fullText+=item.delta.text||"";
          answer.innerHTML=formatAIText(fullText);
          out.scrollTop=out.scrollHeight;
        }
      }
    }
    if(!fullText.trim())throw new Error("Gemini returned an empty response.");
  }catch(error){
    console.error(error);
    out.innerHTML=`<div class="ai-error"><b>AI Advisor unavailable</b><p>${escapeHtml(error.message)}</p><small>Make sure the app is running with <code>node server.js</code> and your AI credentials are configured in <code>.env</code>.</small></div>`;
  }finally{btn.disabled=false;btn.textContent="✦ Ask AI"}
}
function formatAIText(text){
  return escapeHtml(text).replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br>");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
